# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '05d6c9087a106248faddd6e18640c9cbe3ee6e769cb8afc819cc0a0dbd4e05499b8e3fcf0a07d9cb95c967b31d7e91caa7103045da6e82f5d93283238c8d03e4'
